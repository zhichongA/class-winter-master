package com.ideaaedi.demo;

import com.example.normal.util.EncryptUtil;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements ApplicationRunner {
    public DemoApplication() {
    }
    
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
    
    public void run(ApplicationArguments args) throws Exception {
        String sss = EncryptUtil.encrypt("哈喽~JustryDeng");
        System.out.println("<我是业务逻辑的输出>\t 加密(哈喽~JustryDeng)结果：" + sss);
        System.out.println("<我是业务逻辑的输出>\t 解密结果：" + EncryptUtil.decrypt(sss));
    }
}

